@extends('layouts.app')

@section('content')
                <div class="card shadow mb-4">
                <div class="card-header py-3 text-center">
                    <h6 class="m-0 font-weight-bold text-danger">
                          Make Partial Payment for Codefront Invoice for the period October 2024
                        </h6>
                      </div>
                      <div class="card-body">
                        <div class="table-responsive">
                            <table
                              class="table table-bordered"
                              id="dataTable"
                              width="100%"
                              cellspacing="0"
                              style="font-size:13px;text-align:center;white-space:nowrap;"
                            >
                            <thead>
                              <tr>
                                <th>#</th>
                                <th>User</th>
                                <th>Email</th>
                                <th>Loan Amount</th>
                                <th>Interest</th>
                                <th>Amount Payable</th>
                                <th>Status</th>
                                <th>Date paid</th>
                                <th>Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>1. </td>
                                <td>Martin Njoroge</td>
                                <td>martin@gmail.com</td>
                                <td>10,100</td>
                                <td>550</td>
                                <td>10,600</td>
                                <td>Paid</td>
                                <td>21 Oct 2024</td>
                                <td>
                                    <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#approval-m-1">
                                     <i class='fas fa-money-bill' aria-hidden='true'></i>
                                    </button>
                                </td>
                              </tr>

                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>

                                             <!-- Approve Modal-->      
     <div class="modal fade" id="approval-m-1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
     <div class="modal-dialog modal-dialog-centered" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title text-primary" id="exampleModalLabel">User: martin@gmail.com</h5>
                 <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">×</span>
                 </button>
             </div>
             <div class="modal-body">
                 <form action="{{route('payment_status')}}" method="POST">
                    @method('POST')
                    @csrf
                    <input type="hidden" name="loan_id" value="1">
                    <input type="hidden" name="type" value="1">
                    <div class="row">
                     <div class="col-md-12">
                         <div class="mb-3">
                             <label class="form-label">Payment Status</label>
                             <select name="payment_status" class="form-control form-select" id="paymentStatus">
                                 <option value="2">UnPaid</option>
                                 <option value="1">Paid</option>
                             </select>
                         </div>
                     </div>
                 </div>
                 
                 
                 <div class="row" id="commentsRow">
                     <div class="col-md-12 mt-1">
                         <div class="mb-3">
                             <label for="field-2" class="form-label">Comments</label>
                             <textarea id="textarea" name="desc" class="form-control" required maxlength="3000" rows="3" placeholder="Comments"></textarea>
                         </div>
                     </div>
                 </div>

             </div>
             <div class="modal-footer">
                 <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                 <button class="btn btn-success" type="submit">Proceed</button>
             </div>
         </div>
     </form>
     </div>
  </div>
  <!-- End Approval Modal-->


@endsection