@extends('layouts.app')

@section('content')
<div class="card shadow mb-4">
    <div class="card-header py-3 text-center">
      <h6 class="m-0 font-weight-bold text-primary">
        Loan Requests
      </h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
          <table
            class="table table-bordered"
            id="dataTable"
            width="100%"
            cellspacing="0"
            style="font-size:13px;text-align:center;white-space:nowrap;"
          >

                          
          @php
          $page=$page_number;
      @endphp

            <thead>
              <tr>
                <th>#</th>
                <th class="column-title">Loan ID</th>
                <th class="column-title">Name</th>
                <th class="column-title">Email</th>
                <th class="column-title">Date</th>
                <th class="column-title">Amount</th>
                <th class="column-title">Installments</th>
                <th class="column-title">Period</th>
                <th class="column-title">Scheme</th>
                <th class="column-title">Level</th>
                <th class="column-title">Status</th>
              </tr>
            </thead>
            <tbody>
                                    
                @php
                $page=$page_number;
            @endphp
              @foreach ($data as $loan)                            
                  <tr>
                  <td>{{$page}}. </td>
                  <td>{{$loan['loan_id']}}</td>
                  <td>{{$loan['user_name']}}</td>
                  <td>{{$loan['email']}}</td>
                  <td>{{$loan['date']}}</td>
                  <td>{{number_format($loan['amount'])}}</td>
                  <td>{{number_format($loan['installments'])}}</td>
                  <td>{{$loan['period']}}</td>
                  <td>{{$loan['scheme']}}</td>
                  @if ($loan['level']==1)
                      <td>HR</td>
                  @endif
                  @if ($loan['level']==2)
                      <td>Finance</td>
                  @endif
                  @if ($loan['level']==3)
                      <td>Admin</td>
                  @endif
                  @if ($loan['level']==5)
                      <td>Cleared</td>
                  @endif

                  @if ($loan['status']==1)
                      <td class="text-success">Approved</td>
                  @endif
                  @if ($loan['status']==0)
                      <td class="text-warning">Pending</td>
                  @endif
                  @if ($loan['status']==2)
                      <td class="text-danger">Returned</td>
                  @endif
                  </tr>

                  @php
                  $page+=1;
              @endphp
              @endforeach
            </tbody>
          </table>
        </div>
        

              <!-- Pagination links -->
              <div class="d-flex justify-content-end" style="margin-top: 20px;height:30%;height:1032%"> <!-- Adjust margin-top as needed -->
                  <div style="margin-right: 0; text-align: right; font-size: 14px; color: #555;">
                      {{ $data->appends(request()->except('page'))->links('vendor.pagination.simple-bootstrap-4')}}
                  </div>
              </div>

    </div>
  </div>
@endsection