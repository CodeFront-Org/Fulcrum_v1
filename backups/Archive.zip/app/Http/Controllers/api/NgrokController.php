<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class NgrokController extends Controller
{
    public function test(){
        Log::channel('ngrok')->notice('Ngrok and m server is running');
    }
    public function mpesa_test(Request $request){
        Log::channel('ngrok')->notice('MPESA Callback is working');
        $response = json_decode($request->getContent());
        $response=json_encode($response);

        // Decode the JSON data into an associative array
        $data = json_decode($response, true);

        // Extract the ResultDesc value from the array
        $resultCode = $data['Body']['stkCallback']['ResultCode'];

        // Perform some action based on the response
        if($resultCode == 0) {// Payment successful, do something
        //Log all activity
        Log::channel('ngrok')->notice("Mpesa Success: ".$resultCode." ".print_r($data,true));
    }else{
        Log::channel('ngrok')->notice("Mpesa Success: ".$resultCode." ".print_r($data,true));
    }
}

}