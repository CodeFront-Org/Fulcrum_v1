<?php

namespace App\Http\Controllers\api\auth;

use App\Http\Controllers\Controller;
use App\Models\Logged;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Carbon\Carbon;
use Illuminate\Filesystem\Cache;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Cache as FacadesCache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Str;

class LoginController extends Controller
{

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    protected function authenticate(Request $request)
    {

        //Check if Login attempts are reached
        $limits=$this->limit($request->ip());
        if($limits){
            return response()->json(['status'=>false,'msg'=>"Login Attempts Exceeded. Please Try again in: $limits seconds"],401);
        }else{
            $credentials = $request->only('email', 'password');

            if (Auth::attempt($credentials)) {
                $user = Auth::user();
                $token = $user->createToken('Personal Access Token')->plainTextToken;
                //Log user Data for login
                $this->logUserData($user);
                //Delete any db logs for wrong login attempts
                $id=Logged::where('ip',$request->ip())->pluck('id')->first();
                Logged::find($id)->delete();
                return response()->json(['status'=>true,'msg'=>'Logged in successfully','token' => $token],200);
            }else{
                return response()->json(['status'=>false,'msg'=>'Wrong email or password'],401);
            }
        }
    }
    
    /**
     * Method to Log all users activity for login both in the logs and DB
     */
    public function logUserData($user){
        $currentDateTime = Carbon::now();
        $currentDateTimeMilliseconds = $currentDateTime->format('d F Y H:i:s');
        Log::channel('user_login')->notice($user->email." of DB_ID ".$user->id." Logged in at: ".$currentDateTimeMilliseconds);
        $currentDateTimeFormatted = $currentDateTime->format('Y-m-d H:i:s');
        User::where('id',$user->id)->update(['last_login'=>$currentDateTimeFormatted]);
    }

    /**
     * Putting a limit on number of wrong logins attempt for same IP
     */
    public function limit($ip){
        $check=Logged::where('ip',$ip)->exists();
        if($check){
            $id=Logged::where('ip',$ip)->pluck('id')->first();
            $record=Logged::find($id);
            $attempt=$record->attempts;
            if($attempt>env('Login_Attempts')){//Max number of login attempt
                //Check if it has expired. For now i use 10 seconds
                $time_created=$record->updated_at;
                // Get the current time
                $current_time = Carbon::now();

                // Calculate the difference in seconds
                $time_difference = $current_time->diffInSeconds($time_created);

                // Check if the time difference is greater than env('Lock_Time') seconds
                if ($time_difference > env('Lock_Time')) { //Means the session has expired and we can allow user to attempt for another login. Delete old record
                    $record->delete();
                } else {
                    return env('Lock_Time')-$time_difference; //to get time in decreasing order 
                }
            }else{
                Logged::where('ip',$ip)->update(['attempts'=>($attempt+1)]);
                return false; 
            }
        }else{//Create a new record for new IP login attempt
            Logged::create(['ip'=>$ip]);
        }
    }

    /**
     * Method to check Login status
     */
    public function checkLoginStatus(Request $request)
    {
        // Check if the provided token is valid and associated with an authenticated user.
        //Token is used behind the scene by sanctum
        if (Auth::guard('sanctum')->check()) {
            // User is logged in
            // Extend the token's expiry time by minutes from env file
            $user = Auth::guard('sanctum')->user();
            $tokenName = 'Personal Access Token';

            // Delete the previous token with the same name
            $user->tokens()->where('name', $tokenName)->delete();

            // Create a new token for the user
            $token = $user->createToken('Personal Access Token')->plainTextToken;

            return response()->json(['status' => true, 'message' => 'User is logged in.','token'=>$token]);
        } else {
            // User is not logged in
            return response()->json(['status' => false, 'message' => 'User is not logged in.']);
        }
    }

    /**
     * Logout the authenticated user.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout(Request $request)
    {
        // Check if the request is authenticated
        if (Auth::guard('sanctum')->check()) {
            // User is authenticated via Sanctum guard
            Auth::guard('sanctum')->user()->tokens()->delete();
            return response()->json(['status'=>true,'message' => 'Successfully logged out'],200);
        } else {
            return response()->json(['error' => 'User not authenticated'], 401);
        }
    }
}
