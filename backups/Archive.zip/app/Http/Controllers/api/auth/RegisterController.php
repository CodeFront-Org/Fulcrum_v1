<?php

namespace App\Http\Controllers\api\auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Spatie\Permission\Models\Role;

class RegisterController extends Controller
{
    /**
     * Ensures that all methods in the RegisterController can only be accessed by guests 
     * (unauthenticated users). If a user is authenticated, they won't be able to access 
     * these routes and will be redirected elsewhere, typically to a dashboard or home page.
     *
     * @return void
    */
    public function __construct()
    {
        $this->middleware('guest');
    }


    /**
     * Route To register Users
     * @param Request $request
     * @return Response
     */
    public function register(Request $request){
        $first_name=$request->first_name;
        $last_name=$request->last_name;
        $contacts=$request->contacts;
        $email=$request->email;
        $role_type=$request->role;
        $password=$request->password;

        // Validate the request data
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'contacts' => 'required|string|max:255',
            'email' => 'required|email|unique:users',
            'password' => ['required', 'string', 'min:4', 'confirmed'],
            'terms_accepted' => 'required|accepted', // New rule for terms acceptance checkbox
        ], [
            'terms_accepted.required' => 'You must accept the terms and conditions.', // Custom error message
            'terms_accepted.accepted' => 'You must accept the terms and conditions.', // Custom error message
        ]);
        // Check if validation fails
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors(),
            ], 422); // Unprocessable Entity
        }
        $save=User::create([
            'first_name'=>$first_name,
            'last_name'=>$last_name,
            'contacts'=>$contacts,
            'email'=>$email,
            'role_type'=>$role_type,
            'password'=>Hash::make($password)
        ]);
        if($save){
            //Add role to user
            $role = Role::where('name', 'user')->first();
            if ($role) {
                $save->assignRole('user');
            } else {// Handle case where 'user' role doesn't exist
                return response()->json(['status'=>false,'msg'=>'Role User does not exist']);
            }
            return response()->json([
                'status'=>true,
                'msg'=>'User Registered Successfully'
            ],200);
        }else{
            return response()->json([
                'status'=>false,
                'msg'=>'Failed'
            ],500);
        }
    }
}
