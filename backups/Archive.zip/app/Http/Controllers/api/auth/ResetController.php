<?php

namespace App\Http\Controllers\api\auth;

use App\Http\Controllers\Controller;
use App\Mail\ResetPasswordMail;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class ResetController extends Controller
{
    /**
     * Method that will check if the email provided is correct and send otp for verification
     * @param email
     * @return otp
     */
    public function resetLink(Request $request){
        $email=$request->email;
        if(!empty($email)){
            //Verify email exists in the db
            if(User::where('email',$email)->exists()){//User exists
                // //Generate and send OTP
                // $otp = Str::random(2)."".random_int(0,9).random_int(1,9)."".Str::random(2);
                // $otp=Str::upper($otp);

                //Send Link for reset via email
                $token = Str::random(60);
                $reset_expire=Carbon::now()->addMinutes(env('OTP_EXPIRE'));
                //Send Mail to email provided
                $id=User::where('email',$email)->pluck('id')->first();
                $link=env('VUE_URL').'/reset-password/'.$id.'/'.$token;
                $recipient=$email;
                //Mail::to($recipient)->send(new ResetPasswordMail($link, $recipient));
                //update token in db
                User::where('id',$id)->update(['reset_code'=>$token,'reset_expiry'=>$reset_expire]);
                return response()->json(["status"=>true,"msg"=>"Reset Link Sent To $email","link"=>$link],200);
            }else{//Email provided does not exists
                return response()->json(["status"=>false,"error"=>"This email does not exist in our records."],404);
            }
        }else{//User provided an empty email address
            return response()->json(["status"=>false,"error"=>"Email should not be empty"],404);
        }
    }

    /**
     * Method that will redirect user to reset page provided that the token and id exists
     * @param $id, $token
     */
    public function index($id,$token){
        //verify token sent from email is same as one in db and check if its empty
        $tkn=User::where('id',$id)->pluck('reset_code')->first();
        if($tkn){//Token exists now compare it
            if($token===$tkn){
                //Check if token has expired
                if($this->tokenHasExpired($id)){//Token expired
                    return response()->json(["status"=>false,"code"=>2,"error"=>"Token has Expired. Please visit reset page to continue."],404);
                }else{// Token has not expired
                    return response()->json(["status"=>true,"code"=>1,"msg"=>"Please wait as you are redirected to reset page."],200);
                }
            }else{// Tokens do not match
                return response()->json(["status"=>false,"code"=>3,"error"=>"Token mismatch."],401);
            }
            $name=User::where('id',$id)->pluck('first_name')->first();
            return view('auth.reset',compact('token','name','id'));
            }else{//Empty token in db
                return response()->json(["status"=>false,"code"=>4,"error"=>"Reset token not found. Please visit the reset page to reset your password."],404);
            }
    }

    /**
     * Method to reset your password. Request comeing from reset page
     * @param $newpsw, $conpsw, $userId
     * @return 
     */
    public function reset(Request $request){
        $newpsw=$request->newpsw;
        $conpsw=$request->conpsw;
        $user_id=$request->user_id;

        //Check if token expired
        if($this->tokenHasExpired($user_id)){
            return response()->json(["status"=>false,"error"=>"Token has expired. Please visit reset page to continue."],404);
        }
        //Confirm psw check
        if($newpsw!==$conpsw){
            return response()->json(["status"=>false,"error"=>"Password mismatch. Confirm passwords entered"],404);
        }
        //Update Password
        $update=User::where("id",$user_id)->update(['password'=>$newpsw]);
        if($update){
            return response()->json(["status"=>true,'msg' => 'Password Updated successfully'], 200);
        }else{
            return response()->json(["status"=>false,'error' => 'An unexpected error occurred. Please try again later.'], 500);
        }
    }

     /**
     * Method to verify if a token has expired
     * @param $id id for user
     * @return Boolean
     */
    public function tokenHasExpired($id){
        $expire=User::where('id',$id)->pluck('reset_expiry')->first();
        if(Carbon::now()->gt($expire)){
            return true;
        }else{//token has not expired
            return false;
        }
    }

}
