<?php

namespace App\Http\Controllers\API\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Spatie\Permission\Models\Role;

class RegisterAdminController extends Controller
{
    public function registerAdmin(Request $request){
        $first_name=$request->first_name;
        $last_name=$request->last_name;
        $contacts=$request->contacts;
        $email=$request->email;
        $password=$request->password;

        // Validate the request data
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'contacts' => 'required|string|max:255',
            'email' => 'required|email|unique:users',
            'password' => ['required', 'string', 'min:4', 'confirmed'],
            'terms_accepted' => 'required|accepted', // New rule for terms acceptance checkbox
        ], [
            'terms_accepted.required' => 'You must accept the terms and conditions.', // Custom error message
            'terms_accepted.accepted' => 'You must accept the terms and conditions.', // Custom error message
        ]);
        // Check if validation fails
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors(),
            ], 422); // Unprocessable Entity
        }
        $save=User::create([
            'first_name'=>$first_name,
            'last_name'=>$last_name,
            'contacts'=>$contacts,
            'email'=>$email,
            'password'=>Hash::make($password)
        ]);
        if($save){
            //Add role to user
            $role = Role::where('name', 'admin')->first();
            if ($role) {
                $save->assignRole('admin');
            } else {// Handle case where 'user' role doesn't exist
                return response()->json(['status'=>false,'msg'=>'Role does not exist']);
            }
            return response()->json([
                'status'=>true,
                'msg'=>'Admin Registered Successfully'
            ],200);
        }else{
            return response()->json([
                'status'=>false,
                'msg'=>'Failed'
            ],500);
        }
    }
}
