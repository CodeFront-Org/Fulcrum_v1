<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class Pesapal extends Controller
{
    public function token(){
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => env("PESAPAL_URL"),
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS =>'{
            "consumer_key":"'.env('PESAPAL_CONSUMER_KEY').'",
            "consumer_secret":"'.env('PESAPAL_CONSUMER_SECRET').'"
        }',
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
          ),
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        // Decode the JSON string
        $data = json_decode($response, true);

        // Check if the "token" key exists
        if (isset($data['token'])) {
            // Access the token
            $token = $data['token'];
        } else {
            // Handle the case where the "token" key is not present in the response
            echo 'Token not found in the response.';
        }
        return $token;
    }

    public function RegisterIPNURL($token){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => env("PESAPAL_REGISTER_IPN"),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>'{
            "url": "'.env('PESAPAL_CALLBACK_URL').'",
            "ipn_notification_type": "Post"
        }',
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Authorization: Bearer '.$token
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        $response = json_decode($response, true);
        return $response;

    }

    public function GetIPNList($token){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => env('PESAPAL_GetIPNList_URL'),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => array(
            'Authorization: Bearer '.$token
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        $response = json_decode($response, true);
        return $response;
    }

    public function SubmitOrderRequest($id,$ipn_id,$token,$payload){
        //Getting payload data coming from website
        foreach($payload as $p){
            $amount=$p['amount'];
            $desc=$p['desc'];
            $email=$p['email'];
            $phone=$p['phone'];
            $f_name=$p['first_name'];
            $l_name=$p['last_name'];
        }
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => env('PESAPAL_SubmitOrderRequest_URL'),
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS =>'{
            "id":"'.$id.'",
            "currency": "KES",
            "amount":'.$amount.',
            "description": "'.$desc.'",
            "callback_url": "'.env('PESAPAL_ORDER_CALLBACK_URL').'",
            "notification_id": "'.$ipn_id.'",
            "billing_address": {
                "email_address": "'.$email.'",
                "phone_number": "'.$phone.'",
                "country_code": "KE",
                "first_name": "'.$f_name.'",
                "middle_name": "",
                "last_name": "'.$l_name.'",
                "line_1": "Codefront",
                "line_2": "Codefront",
                "city": "",
                "state": "",
                "postal_code": "",
                "zip_code": ""
            }
        }
        ',
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Authorization: Bearer '.$token
          ),
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        $response = json_decode($response, true);
        return $response;
    }


    public function pesapal(Request $request){
        return$token=$this->token();
        $data=$this->RegisterIPNURL($token);
        $payload=[];

        // Extract id and ipn_id
        $id = 30;
        $ipnId = $data['ipn_id'];
        //Extracting Payload Data
        $amount=$request->amount;
        $desc=$request->desc;//eg Codefront rentals acc
        $f_name=$request->first_name;
        $l_name=$request->last_name;
        $phone=$request->phone_number;
        $email=$request->email_address;

        array_push($payload,[
            'amount'=>$amount,
            'desc'=>$desc,
            'first_name'=>$f_name,
            'last_name'=>$l_name,
            'phone'=>$phone,
            'email'=>$email,
        ]);

        $data=$this->SubmitOrderRequest($id,$ipnId,$token,$payload);
        echo "OrderTrackId: ".$data['order_tracking_id'];
        echo "----Merchant: ".$data['merchant_reference'];
        echo "----URL: ".$data['redirect_url'];
        return;

    }

    public function GetTransaction(){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => env('PESAPAL_GET_TRANSACTION_URL'),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => array(
            'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL3VzZXJkYXRhIjoiOTY5Mzg3NTMtYTE4NS00MjEyLThkMWMtZGQ5YzYxYWQ3OTE3IiwidWlkIjoiQ2R0QnAvaEliaGVNSE1Gb0ZjOFN4NlZhK1NzdEVvaTciLCJuYmYiOjE3MDc0OTY3MTQsImV4cCI6MTcwNzQ5NzAxNCwiaWF0IjoxNzA3NDk2NzE0LCJpc3MiOiJodHRwOi8vcGF5LnBlc2FwYWwuY29tLyIsImF1ZCI6Imh0dHA6Ly9wYXkucGVzYXBhbC5jb20vIn0.zcihhfFcuMCB22jDl2-YrImMrOOoRCUCwM4lRR-RMPM'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        echo $response;
    }

    public function ipn(Request $request){
        $response = json_decode($request->getContent());
        Log::channel('pesapal')->notice("Pesapal IPN: ".print_r($response,true));

    }

    public function order(Request $request){
        //Log::channel('pesapal')->notice("Pesapal Order: ".$request);
        $orderTrackingId = $request->query('OrderTrackingId');
        $orderMerchantReference = $request->query('OrderMerchantReference');
        return "Track: ".$orderTrackingId."<br> Merchant".$orderMerchantReference;
    }


}
