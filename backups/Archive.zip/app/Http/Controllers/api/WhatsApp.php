<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class WhatsApp extends Controller
{
    /*********************************************** Route to register callback url registered in the developer account *********************************************/
    public function whatsapp_register_callback(Request $request){//Route to verify token
        $token=env("CallBackUrlToken");//password you set in fb and in your app
        $receivedVerifyToken = $request->input('hub_verify_token'); // WhatsApp's secret code

        if ($receivedVerifyToken === $token) {
            // It's really WhatsApp! We can process the message.
            // Put your code here to handle the message.
            Log::channel('wa-token')->notice("Registered successfully. Received token: ".$receivedVerifyToken);
            return response($request->hub_challenge, 200);//Will be used by FB to verify authenticity
        } else {
            // The secret code doesn't match. It might be a trick.
            return response('Invalid Verify Token', 403);
        }
    }


    /*********************************************** Route to receive or listen to callback url from the webhook *********************************************/
    public function webhook(Request $request){
        $response = json_decode($request->getContent(), true);
        //Log::channel('wa-webhook')->notice(print_r($response,true));//return "Success";
        // Help know if its from the user or its just callback from whatsapp webhook
        if (isset($response['entry'][0]['changes'][0]['value']['statuses'][0]['status'])) { //This means its from the webhook when a txt is sent by the server
            // The 'status' field is present in the array
            $status = $response['entry'][0]['changes'][0]['value']['statuses'][0]['status'];
            Log::channel('wa-webhook')->notice("SERVER message status: $status");
            return response()->json(['message' => 'Request received and processed successfully']);
            exit();
            return;
        } else {//Means message is coming from the user
            // The 'status' field is not present
            Log::channel('wa-webhook')->notice("User message.");
        }

        // Extracting the field for contacts
        $entry = $response['entry'][0]['changes'][0]['value']['messages'][0];
        $to = $entry['from'];// user phone number

        $this->sendMsgTemp($to,"helloworld");
        
    }

    
    public function track($track,$to){//Help in storing messages session so as to know which message is to be sent next
        if($track==0){//Newly registered user and about to start the prompt questions
            $msg="🏫 Welcome to CodeFront School! 📚 \n

                    Dear Parent, \n
                    
                    We are delighted to have you as a part of our CodeFront School community. 🎉 \n
                    
                    Your child's education is our priority, and we are here to support you every step of the way. \n
                    
                    Thank you for choosing CodeFront School for your child's education! 📖";
            $this->sendMsg($to,$msg);
        }elseif($track==1){

        }else{

        }
    }


    /*********************************************** Send message with a template *********************************************/
    public function sendMsgTemp($to,$name){
        $response = Http::withHeaders([
            'Authorization' => 'Bearer '.env('FACEBOOK_ACCESS_TOKEN'),
            'Content-Type' => 'application/json',
        ])
        ->post("https://graph.facebook.com/".env('WA_VERSION')."/".env('PHONE_ID')."/messages", [
            'messaging_product' => 'whatsapp',
            'to' => $to,
            'type' => 'template',
            'template' => [
                'name' => $name,
                'language' => [
                    'code' => 'en_US',
                ],
            ],
        ]);
    }


    /*********************************************** Send Plain message *********************************************/
    public function sendMsg($to,$msg){
        $response = Http::withHeaders([
            'Authorization' => 'Bearer '.env('FACEBOOK_ACCESS_TOKEN'),
            'Content-Type' => 'application/json',
        ])
        ->post("https://graph.facebook.com/".env('WA_VERSION')."/".env('PHONE_ID')."/messages", [
            'messaging_product' => 'whatsapp',
            'to' => $to,
            'type' => 'text',
            'text' => [
                'body' => $msg,
            ],
        ]);
    }


    /*********************************************** Send Image *********************************************/
    public function sendImage($to,$link){
        $response = Http::withHeaders([
            'Authorization' => 'Bearer '.env('FACEBOOK_ACCESS_TOKEN'),
            'Content-Type' => 'application/json',
        ])
        ->post("https://graph.facebook.com/".env('WA_VERSION')."/".env('PHONE_ID')."/messages", [
            'messaging_product' => 'whatsapp',
            'to' => $to,
            'type' => 'image',
            'image' => [
                'link' => 'https://i.imgur.com/h2sKfWA.jpeg',
            ],
        ]);
        
        // To get the response content:
        $responseBody = $response->body();
        
        // To get the response status code:
        $responseStatus = $response->status();
    }
    

    /*********************************************** Send Contacts *********************************************/
    public function sendContacts($to,$msg){
        $response = Http::withHeaders([
            'Authorization' => 'Bearer '.env('FACEBOOK_ACCESS_TOKEN'),
            'Content-Type' => 'application/json',
        ])
        ->post("https://graph.facebook.com/".env('WA_VERSION')."/".env('PHONE_ID')."/messages", [
                'messaging_product' => 'whatsapp',
                'to' => $to,
                'type' => 'contacts',
                'contacts' => [
                    [
                        'addresses' => [
                            [
                                'street' => 'Nairobi',
                                'city' => 'Nairobi City',
                                'country' => 'Kenya',
                                'country_code' => '254',
                                'type' => 'WORK',
                            ],
                        ],
                        'emails' => [
                            [
                                'email' => 'martinnjoroge0028@gmail.com',
                                'type' => 'WORK',
                            ],
                        ],
                        'name' => [
                            'formatted_name' => 'Martin Njoroge',
                            'first_name' => 'Martin',
                            'last_name' => 'Njoroge',
                        ],
                        'org' => [
                            'company' => 'CodeFront',
                            'department' => 'DEPARTMENT',
                            'title' => 'TITLE',
                        ],
                        'phones' => [
                            [
                                'phone' => '0797965688',
                                'type' => 'WORK',
                            ],
                        ],
                        'urls' => [
                            [
                                'url' => '<URL>',
                                'type' => 'WORK',
                            ],
                        ],
                    ],
                ],
            ]);

        // To get the response content:
        $responseBody = $response->body();

        // To get the response status code:
        $responseStatus = $response->status();
    }


    /*********************************************** Send PDF *********************************************/
    public function sendPDF(){
        $response = Http::withHeaders([
            'Authorization' => 'Bearer '.env('FACEBOOK_ACCESS_TOKEN'),
            'Content-Type' => 'application/json',
            ])
        ->post("https://graph.facebook.com/".env('WA_VERSION')."/".env('PHONE_ID')."/messages", [
        'messaging_product' => 'whatsapp',
        'to' => '254797965680',
        'type' => 'document',
        'document' => [
            'link' => 'https://www.youthcentral.vic.gov.au/sites/default/files/YouthCentral_CoverLetter_WorkExperience_March-27-2017.pdf',
            'filename' => 'Cover Letter',
        ],
        ]);

        // To get the response content:
        $responseBody = $response->body();

        // To get the response status code:
        $responseStatus = $response->status();
    }


    /*********************************************** Send Video *********************************************/
    public function sendVideo($to,$msg){
    }


    /*********************************************** Send URL LINK *********************************************/
    public function sendURL($to,$msg){
    }

}
