<?php

namespace App\Http\Controllers\app;

use App\Http\Controllers\Controller;
use App\Models\Loan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ApprovalController extends Controller
{
    public function approve(Request $request){
        $type=$request->type;
        //Check role of who is approving
        $role_type=auth()->user()->role_type;
        if($role_type=='hro'){
            $approval_level=2;
            $level=1;
        }
        if($role_type=='finance'){
            $approval_level=3;
            $level=2;
        }
        if($role_type=='admin'){
            $approval_level=4;
            $level=3;
        }

        if($type==1){ //Approve
            try {
                $loan_id=$request->loan_id;
                $desc=$request->desc;
                Loan::where('id',$loan_id)->update([
                    'approval_level'=>$approval_level,
                    'approver'.$level.'_id'=>Auth::id(),
                    'approver'.$level.'_action'=>'RECOMMENDED',
                    'approver'.$level.'_comments'=>$desc,
                    'approver'.$level.'_date'=>date('Y-m-d H:i:s')
                ]);

                //Check if its admin and make final approval
                $role_type=auth()->user()->role_type;
                if($role_type=='admin'){
                    Loan::where('id',$loan_id)->update([
                        'final_decision'=>1,
                        'mpesa_transaction'=>$request->trx,
                        'progress'=>0,
                        'approval_level'=>0
                    ]);
                }

                session()->flash('message',"The loan $loan_id has been approved successfully");
                return back();
            } catch (\Throwable $th) {
                session()->flash('error',"An error occurred while approving LoanID $loan_id. Please try again later");
                return back();
            }
        }elseif($type==2){ //Reject
            //Check role of who is approving
            $role_type=auth()->user()->role_type;
            if($role_type=='hro'){
                $approval_level=1;
                $level=1;
            }
            if($role_type=='finance'){
                $approval_level=2;
                $level=2;
            }
            if($role_type=='admin'){
                $approval_level=3;
                $level=3;
            }
            try {
                $loan_id=$request->loan_id;
                $desc=$request->desc;
                Loan::where('id',$loan_id)->update([
                    'approval_level'=>$approval_level, //remains same so that we know who returned the loan easily
                    'approver'.$level.'_id'=>Auth::id(),
                    'approver'.$level.'_action'=>'RETURNED',
                    'final_decision'=>2,
                    'approver'.$level.'_comments'=>$desc,
                    'approver'.$level.'_date'=>date('Y-m-d H:i:s')
                ]);
                session()->flash('message',"The loan $loan_id has been Returned.");
                return back();
            } catch (\Throwable $th) {
                session()->flash('error',"An error occurred while returning LoanID $loan_id. Please try again later");
                return back();
            }
        }
    }

}
