<?php

namespace App\Http\Controllers\app;

use App\Http\Controllers\Controller;
use App\Models\Access;
use App\Models\Loan;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function dashboard(){
        //Get user role so as to redirect the correct view accordingly
        if (Auth::check()) {
             $role = Auth::user()->role_type;
            if($role=='user'){
                return $this->userDash();
            }elseif($role=='hro'){
                return $this->hroDash();
            }elseif($role=='finance'){
                return $this->financeDash();
            }elseif($role=='admin'){
                return $this->adminDash();
            }
            
        }else{
            return redirect('/login');
        }
    }


    //User user dash
    public function userDash(){
        $label="Dashboard";

        $loans=Loan::where('user_id',Auth::id())->whereOr('progress',[5,0])->latest()->get();

        $tot_request=count($loans);
        $tot_amt=Loan::select('requested_loan_amount')->where('user_id',Auth::id())->where('final_decision',1)->sum('requested_loan_amount');
        $approved=count(Loan::select('requested_loan_amount')->where('user_id',Auth::id())->where('final_decision',1)->get());
        $returned=count(Loan::select('requested_loan_amount')->where('user_id',Auth::id())->where('final_decision',2)->get());
        return view('app.dash.user',compact(
            'label',
            'loans',
            'tot_request',
            'tot_amt',
            'approved',
            'returned',
        ));
    }


    //User hro
    public function hroDash()
    {
        $label = "Dashboard";

        $company_ids=Access::select('company_id')->where('user_id',Auth::id())->get();
        $loans=Loan::where('approval_level',1)->where('final_decision',0)->whereIn('company_id', $company_ids)->where('progress',5)->get();
    
        return view('app.dash.hro', compact('label', 'loans'));
    }
    

    //User finance
    public function financeDash(){
        $label = "Dashboard";

        $company_ids=Access::select('company_id')->where('user_id',Auth::id())->get();
        $loans=Loan::where('approval_level',2)->where('final_decision',0)->whereIn('company_id', $company_ids)->where('progress',5)->get();
    
        return view('app.dash.finance', compact('label', 'loans'));
    
    }

     //User Admin
    public function adminDash(){
        $label="Dashboard";

        $company_ids=Access::select('company_id')->where('user_id',Auth::id())->get();
        $loans=Loan::where('approval_level',3)->where('final_decision',0)->whereIn('company_id', $company_ids)->where('progress',5)->latest()->get();

        return view('app.dash.admin',compact('label','loans'));
    }

}
