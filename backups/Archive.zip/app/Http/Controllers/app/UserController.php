<?php

namespace App\Http\Controllers\app;

use App\Http\Controllers\Controller;
use App\Models\Company;
use App\Models\User;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Mail\ResetPasswordMail;
use App\Http\Controllers\app\SmsController;
use App\Models\Access;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    protected $smsController;

    // Inject SmsController in the constructor
    public function __construct(SmsController $smsController)
    {
        $this->smsController = $smsController;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $label="Users";

        $users=User::where('role_type','user')->latest()->get();
        $companies = Company::orderBy('name', 'asc')->get();

        $users_count=count($users);

        return view('app.admin.users',compact(
            'label',
            'users',
            'companies',
            'users_count',
        ));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //return $request;
        //Get Company ID
        $company_id=Company::where('name',$request->company)->pluck('id')->first();
        if(!$company_id){
            session()->flash('error','The Selected Company Does Not EXIST. Please select a valid company');
            return back();
        }

        try {
            //Save User Info
            //dummy password
            $psw=Str::random(40);
            $user=User::create([
                    'first_name'=>$request->first_name,
                    'last_name'=>$request->last_name,
                    'email'=>$request->email,
                    'contacts'=>$request->contacts,
                    'id_number'=>$request->id_number,
                    'gender'=>$request->gender,
                    'pin_certificate'=>$request->pin,
                    'staff_number'=>$request->staff_no,
                    'employment_date'=>$request->employment_date,
                    'employment_type'=>$request->emp_type==1?'PERMANENT':'CONTRACT',
                    'contract_end'=>$request->contract_end,
                    'role_type'=>'user',
                    'password'=>Hash::make($psw)
                ]);
            //Assign Role user
            $user->assignRole('user');

            //Access to company
            Access::create([
                'user_id'=>$user->id,
                'company_id'=>$company_id
            ]);

            //Create Token to be sent to Email and SMS for next auth
            $token = Str::random(10);
            $reset_expire=Carbon::now()->addMinutes(5);

            //Send Mail to email provided
            $user_id=$user->id;
            $link=env('APP_URL').'/reset-password/'.$user_id.'/'.$token;
            // $recipient=$email;
            // Mail::to($recipient)->send(new ResetPasswordMail($link, $recipient));

            //Send SMS
            $msg = "Dear {$request->first_name},\n" .
            "Thank you for creating an account with us. " .
            "Use the link below to create your password.\n" .
            "{$link} \n\n".
            "Fulcrum";
            $this->smsController->send_sms($request->contacts,$msg);
            

            //update token in db
            User::where('id',$user_id)->update(['reset_code'=>$token,'reset_expiry'=>$reset_expire]);

            session()->flash('message','User Registered Successfully. We have sent a link via mail and SMS for the user to setup their account ');
            return back();

        } catch (\Throwable $th) {
             return $th->getMessage();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    ////////////////////////////////////////////// Admin Method to do the Cruds ///////////////////////////////////////
    public function addAdmin(Request $request){
        //Check Authentication
        if(Auth::check() && auth()->user()->role_type==='admin'){
            return $request;
        //Get Company ID
        // $company_id=Company::where('name',$request->company)->pluck('id')->first();
        // if(!$company_id){
        //     session()->flash('error','The Selected Company Does Not EXIST. Please select a valid company');
        //     return back();
        // }

        try {
            //Save User Info
            //dummy password
            $psw=Str::random(40);
            $user=User::create([
                    'first_name'=>$request->first_name,
                    'last_name'=>$request->last_name,
                    'email'=>$request->email,
                    'contacts'=>$request->contacts,
                    'id_number'=>$request->id_number,
                    'gender'=>$request->gender,
                    'pin_certificate'=>$request->pin,
                    'staff_number'=>$request->staff_no,
                    'employment_date'=>$request->employment_date,
                    'employment_type'=>$request->emp_type,
                    'contract_end'=>$request->contract_end,
                    'role_type'=>'user',
                    'password'=>Hash::make($psw)
                ]);
            //Assign Role user
            $user->assignRole('user');

            //Access to company
            // Access::create([
            //     'user_id'=>$user->id,
            //     'company_id'=>$company_id
            // ]);

            //Create Token to be sent to Email and SMS for next auth
            $token = Str::random(10);
            $reset_expire=Carbon::now()->addMinutes(5);

            //Send Mail to email provided
            $user_id=$user->id;
            $link=env('APP_URL').'/reset-password/'.$user_id.'/'.$token;
            // $recipient=$email;
            // Mail::to($recipient)->send(new ResetPasswordMail($link, $recipient));

            //Send SMS
            $msg = "Dear {$request->first_name},\n" .
            "Thank you for creating an account with us. " .
            "Use the link below to create your password.\n" .
            "{$link} \n\n".
            "Fulcrum";
            $this->smsController->send_sms($request->contacts,$msg);
            

            //update token in db
            User::where('id',$user_id)->update(['reset_code'=>$token,'reset_expiry'=>$reset_expire]);

            session()->flash('message','User Registered Successfully. We have sent a link via mail and SMS for the user to setup their account ');
            return back();

        } catch (\Throwable $th) {
             return $th->getMessage();
        }
        }else{
            abort(401);
        }
    }

    public function getAdmins(Request $request){
        //Check Authentication
        if(Auth::check() && auth()->user()->role_type==='admin'){
            $label="Administrators";

            return view('app.admin.admin',compact('label'));
        }else{
            abort(401);
        }
    }

    public function editAdmin(Request $request){
        //Check Authentication
        if(Auth::check() && auth()->user()->role_type==='admin'){

        }else{
            abort(401);
        }
    }


    public function deleteAdmin(Request $request){
        //Check Authentication
        if(Auth::check() && auth()->user()->role_type==='admin'){

        }else{
            abort(401);
        }
    }

}
