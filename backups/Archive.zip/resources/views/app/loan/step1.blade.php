@extends('layouts.app')

@section('content')
    
<div class="row">
    <div class="card-body col-md-12">

                        <ul class="nav nav-pills navtab-bg nav-justified">
                            <li class="nav-item">
                                <a class="nav-link active no-hover-style">
                                    Info
                                </a>
                            </li>
                            <li class="nav-item">
                                <a  class="nav-link bg-warning no-hover-style">
                                    Salary
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link bg-warning no-hover-style">
                                    Loan 
                                </a>
                            </li>
                            <li class="nav-item">
                                <a  class="nav-link bg-warning no-hover-style">
                                    Terms
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="home1">

                                    <div>
                                        <div  class="modal-dialog1 modal-dialog-centered1 col-8 responsive1">
                                                    <h5 class="modal-title" id="exampleModalLabel">My Personal Details</h5>
                                            <div class="modal-content">
                                                <div class="modal-body">
                                                <form action="{{route('loan.store')}}" method="POST">
                                                    @csrf
                                                    @method('POST')
                                                    <input type="hidden" name="type" value="1">
                                                <div class="row mb-2">
                                                    <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">Applicant ID</label>
                                                        <input
                                                        name="applicant_id"
                                                        type="text"
                                                        value="{{$applicant_id}}"
                                                        class="form-control"
                                                        placeholder="Applicant ID"
                                                        readonly
                                                        required
                                                        />
                                                    </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">First Name</label>
                                                        <input
                                                        name="first_name"
                                                        type="text"
                                                        value="{{$first_name}}"
                                                        class="form-control"
                                                        placeholder="first name"
                                                        readonly
                                                        required
                                                        />
                                                    </div>
                                                    </div>
                                                </div>
                                                <div class="row">

                                                <div class="col-md-6 mb-2">
                                                    <div class="mb-3">
                                                        <label class="form-label">Second Name</label>
                                                        <input
                                                        name="second_name"
                                                        type="text"
                                                        value="{{$last_name}}"
                                                        class="form-control"
                                                        placeholder="second name"
                                                        readonly
                                                        required
                                                        />
                                                    </div>
                                                    </div>

                                                    <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">Contacts</label>
                                                        <input
                                                        name="contacts"
                                                        type="text"
                                                        class="form-control"
                                                        placeholder="contacts"
                                                        value="{{$contacts}}"
                                                        readonly
                                                        required
                                                        />
                                                    </div>
                                                    </div>
                                                    <div class="col-md-6 mb-2">
                                                    <div class="mb-3">
                                                        <label class="form-label">Contract Expires</label>
                                                        <input
                                                        name="contract"
                                                        type="text"
                                                        class="form-control"
                                                        value="{{$contract_end}}"
                                                        readonly
                                                        placeholder="expiry"
                                                        required
                                                        />
                                                    </div>
                                                    </div>


                                                    <div class="col-md-6 mb-2">
                                                    <div class="mb-3">
                                                        <label class="form-label">Designation</label>
                                                        <input
                                                        name="company"
                                                        type="text"
                                                        class="form-control"
                                                        value="{{$company}}"
                                                        placeholder="designation"
                                                        readonly
                                                        required
                                                        />
                                                    </div>
                                                    </div>


                                                    <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">Next Of KIN</label>
                                                        <input
                                                        name="kin"
                                                        type="text"
                                                        class="form-control"
                                                        value="{{$kin}}"
                                                        placeholder="next of kin names"
                                                        required
                                                        />
                                                    </div>
                                                    </div>


                                                    <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">KIN Contacts</label>
                                                        <input
                                                        name="kin_mobile"
                                                        type="text"
                                                        class="form-control"
                                                        value="{{$kin_contacts}}"
                                                        placeholder="kin contacts"
                                                        required
                                                        />
                                                    </div>
                                                    </div>

                                                </div>

                                                </div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-primary" type="submit">Next  <i class="fa fa-arrow-right"></i></button>
                                                </div>
                                            </div>
                                        </form>
                                        </div>
                                    </div>
                                    <!-- End NewStaff Modal-->

                            </div>
                        </div>
                    </div>
    </div>
@endsection