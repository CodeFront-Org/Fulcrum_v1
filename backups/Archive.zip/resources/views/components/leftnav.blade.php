<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand  toggled-->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-usd"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Fulcrum LTD </div>
    </a>
    
    <!-- Divider -->
    <hr class="sidebar-divider my-0">
    
    <!------------------------- Admin Left nav ------------------------------>
        <li class="nav-item">
            <a class="nav-link" href="{{route('dashboard')}}">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span></a>
        </li>
        
        @role(['admin','finance','hro'])
        <li class="nav-item">
            <a class="nav-link" href="{{route('users.index')}}">
                <i class="fas fa-mail-bulk"></i>
                <span>Users</span></a>
        </li>
        @endrole
        
        @role('admin')
        <li class="nav-item">
            <a class="nav-link" href="{{route('admins')}}">
                <i class="fas fa-user-lock"></i>
                <span>Admin</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="{{route('companies.index')}}">
                <i class="fas fa-mail-bulk"></i>
                <span>Designation</span></a>
        </li>
        {{-- <li class="nav-item">
            <a class="nav-link" href="{{route('roles.index')}}">
                <i class="fas fa-user-lock"></i>
                <span>Manage Roles</span></a>
        </li> --}}
        @endrole

        @role('user')
            <li class="nav-item">
                <a class="nav-link" href="{{route('loan.index')}}">
                    <i class="fas fa-mail-bulk"></i>
                    <span>Apply Loan</span></a>
            </li>
        @endrole

        <li class="nav-item">
            <a class="nav-link" href="profile.php">
                <i class="fas fa-user"></i>
                <span>Profile</span></a>
        </li>
    

        <!------------------------- Finance Left nav ------------------------------>
    
    
    
    
    </ul>