<?php

use App\Http\Controllers\api\Pesapal;
use App\Http\Controllers\social_login\AuthController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Laravel\Socialite\Facades\Socialite;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/send-mail',[App\Http\Controllers\MailController::class,'sendEmail'])->name('/send-mail');

Route::get('/', function () {
    return view('auth.login');
});

//Authentication routes
Route::post('/app/login',[App\Http\Controllers\Auth\AuthController::class,'login'])->name('/app/login');
//*******************************end registration */
Route::post('/reset', [App\Http\Controllers\Auth\ResetController::class,'send_link'])->name('reset');//to send reset link
Route::get('/reset-password/{id}/{token}', [App\Http\Controllers\Auth\ResetController::class,'index'])->name('reset-password');//to load reset psw page
Route::post('/reset-psw', [App\Http\Controllers\Auth\ResetController::class,'reset'])->name('reset-psw');//to send reset link

Route::middleware('auth')->group(function () {
//*******************App routes *******************///
Route::get('/dashboard',[\App\Http\Controllers\app\DashboardController::class,'dashboard'])->name('dashboard');
Route::resource('users',\App\Http\Controllers\app\UserController::class);
Route::resource('companies',\App\Http\Controllers\app\CompaniesController::class);
Route::resource('roles',\App\Http\Controllers\app\RolesController::class);
Route::resource('loan', \App\Http\Controllers\app\LoanController::class);
Route::POST('/approve',[\App\Http\Controllers\app\ApprovalController::class,'approve'])->name('approve');


//*******************Add other Admin routes *******************///
Route::get('/admins',[\App\Http\Controllers\app\UserController::class,'getAdmins'])->name('admins');
Route::post('/add-admin',[\App\Http\Controllers\app\UserController::class,'addAdmin'])->name('add-admin');
Route::post('/edit-admin',[\App\Http\Controllers\app\UserController::class,'editAdmin'])->name('edit-admin');
Route::post('/delete-admin',[\App\Http\Controllers\app\UserController::class,'deleteAdmin'])->name('delete-admin');

//*******************end admin routes *******************///

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
});

Auth::routes(); 


